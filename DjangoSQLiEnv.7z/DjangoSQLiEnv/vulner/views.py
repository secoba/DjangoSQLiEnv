# -*- coding: utf-8 -*-
# Author: lynn
# Date: 2019-08-05
"""
views.py
"""

import json

from django.shortcuts import render, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.db import models
from django.contrib.postgres.fields.jsonb import KeyTransform, KeyTextTransform
from django.db.models.functions import Cast

from vulner.models import Test


# Create your views here.

def index(request):
    return render(request, "index.html")


def init_data(request):
    Test.objects.create(name1={"test": "value1111"})
    return HttpResponse("init done")


@csrf_exempt
def query(request):
    if request.method == "GET":
        return render(request, "query.html")
    elif request.method == "POST":
        key = request.POST.get("name")
        value = request.POST.get("value")
        # data = json.loads(request.body.decode())
        # print(data)
        dictionary = {key: value}
        objs = Test.objects.filter(**dictionary)
        print(objs)
        return HttpResponse(objs)
