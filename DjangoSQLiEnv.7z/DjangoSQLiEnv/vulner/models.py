# -*- coding: utf-8 -*-
# Author: lynn
# Date: 2019-08-05
"""
models.py
"""

from django.contrib.postgres.fields import JSONField
from django.db import models


# Create your models here.
# 根据Django文档,JSONField要求PostgreSQL≥9.4且Psycopg2≥2.5.4

class Test(models.Model):
    name1 = JSONField()
    # name2 = HStoreField(null=True)
