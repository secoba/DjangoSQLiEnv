from django.apps import AppConfig


class VulnerConfig(AppConfig):
    name = 'vulner'
